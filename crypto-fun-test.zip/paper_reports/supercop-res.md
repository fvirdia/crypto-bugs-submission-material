Crashes during fuzzing: 52
Crashes during geninput: 387
Crashes on basic test input: 761
Fuzzing runs without crashes: 140150
Compilation Errors: 134
Not enough randomness in results: 0
