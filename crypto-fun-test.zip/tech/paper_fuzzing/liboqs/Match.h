#pragma once

#include "API.h"
#include "../utilities/types.h"
#include "../utilities/fmt_str_parser.h"

void Match(out_t *y, out_t *yp, exp_res_t exp_res);