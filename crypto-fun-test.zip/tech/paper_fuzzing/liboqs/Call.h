#pragma once

#include "API.h"
#include "../utilities/types.h"
#include "../utilities/fmt_str_parser.h"

void Call(out_t *out, in_t *in, pp_t *pp, aux_t *aux, fmt_t *fmt);